package org.medipaw.controller;

import org.medipaw.domain.Criteria;
import org.medipaw.domain.PageDTO;
import org.medipaw.domain.ReservVO;
import org.medipaw.service.ReservService;
import org.medipaw.service.TreatService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/reserv/*")
@AllArgsConstructor
public class ReservController {
	private ReservService rService;
	private TreatService trService;
	
    // 중복 확인을 수행하는 엔드포인트
    @PostMapping("/checkDupl")
    @ResponseBody
    public String checkDuplicate(@RequestParam("rvDate") String rvDate, @RequestParam("rvTime") String rvTime) {
        ReservVO rvvo = new ReservVO();
        rvvo.setRvDate(rvDate);
        rvvo.setRvTime(rvTime);

        if (rService.duplCnt(rvvo) <= 0) {
            return "notduplicate";
        } else {
            return "duplicate";
        }
    }
	
	@PostMapping("register")	
	//@PreAuthorize("isAuthenticated()")
	public String register(ReservVO rvvo, RedirectAttributes rttr) {		
		log.info("registerController...");
		
		if(rService.duplCnt(rvvo) <= 0) {		// 중복 체크 값이 0 이하인 경우에는 예약할 수 있게 함
			if(rService.register(rvvo)) {
				rttr.addFlashAttribute("result", "successR");
			} else {
				rttr.addFlashAttribute("result", "fail");
			}
		} else {
			log.info("예약 중복!");
			rttr.addFlashAttribute("result", "duplicate");
			return "redirect:/reserv/register";
		}
		// 반환이 void면 /WEB-INF/views/reserv/list.jsp로 이동하는데 jsp로 가면 안되고 맵핑된 list로 가야함
		return "redirect:/reserv/listAdm";
		// 얘는 @GetMapping("list")로 이동! -> select된 목록을 갖고 가야하므로 .do로 보내는 것과 동일
	}
	
	@GetMapping("register")
	//@PreAuthorize("isAuthenticated()")
	public void register() {
		log.info("register.jsp...");
	}
	
	@GetMapping({"view", "modify"})		// 원래는 view 컨트롤러였는데 수정하기 전에 수정 폼에서 view처리 해야하므로 묶음
	public void view(Model model, int rvno, @ModelAttribute("cri") Criteria cri) {	// cri를 view.jsp로 넘겨야함
		log.info("viewController....");
		model.addAttribute("treatCnt", trService.treatCnt(rvno));
		model.addAttribute("view", rService.view(rvno));
	}
	
	@PostMapping("modify")
	//@PreAuthorize("principal.username == #bvo.writer")		// modify.jsp의 값들이 넘어와서 그대로 비교
	public String modify(ReservVO rvvo, RedirectAttributes rttr, @ModelAttribute("cri") Criteria cri) {		// BoardControllerTests에서 돌려보기
		log.info("modifyController...");
		
		if(rService.modify(rvvo)) {
			rttr.addFlashAttribute("result", "successM");	// modify가 성공적으로 되면 result에 success 담아서 보내
		} else {
			rttr.addFlashAttribute("result", "fail");
		}
		// redirect는 reponse 객체 사용하는데 @ModelAttribute는 request 객체를 사용해서 결과 페이지까지 못 감
		// 그래서 rttr 사용해서 attribute에 담아서 보냄
		rttr.addAttribute("amount", cri.getAmount());	
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("type", cri.getType());	
		rttr.addAttribute("keyword", cri.getKeyword());
		rttr.addAttribute("rvno", rvvo.getRvno());
		// 반환이 void면 /WEB-INF/views/reserv/list.jsp로 이동하는데 jsp로 가면 안되고 맵핑된 list로 가야함
		return "redirect:/reserv/view";
		// 얘는 @GetMapping("list")로 이동! -> select된 목록을 갖고 가야하므로 .do로 보내는 것과 동일
	}
	
	@PostMapping("remove")
	//@PreAuthorize("principal.username == #writer")
	public String remove(int rvno, RedirectAttributes rttr, @ModelAttribute("cri") Criteria cri) {		// BoardControllerTests에서 돌려보기
		log.info("removeController...");
		
		if(rService.remove(rvno)) {
			rttr.addFlashAttribute("result", "successD");
		} else {
			rttr.addFlashAttribute("result", "fail");
		}
		rttr.addAttribute("amount", cri.getAmount());	
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("type", cri.getType());	
		rttr.addAttribute("keyword", cri.getKeyword());
		
		return "redirect:/reserv/listAdm"; // 권한에 따라 리다이렉트하는 경로 정해주기
	}
	
	@GetMapping("listUser")					
	public void listUser(Model model, String id, Criteria cri) {		
		log.info("listUserController... id : " + id +" / "+ cri);
		model.addAttribute("pageDTOUser", new PageDTO(cri, rService.totalCountUser(id, cri)));
		model.addAttribute("listUser", rService.listPagingUser(id, cri));
	}
	
	@GetMapping("listStaff")					
	public void listStaff(Model model, int hno, Criteria cri) {		
		log.info("listStaffController..." + cri);
		model.addAttribute("pageDTOStaff", new PageDTO(cri, rService.totalCountStaff(hno, cri)));
		model.addAttribute("listStaff", rService.listPagingStaff(hno, cri));
	}
	
	@GetMapping("listAdm")
	public void listAdm(Model model, Criteria cri) {		
		log.info("listAdmController..." + cri);
		model.addAttribute("pageDTOAdm", new PageDTO(cri, rService.totalCountAdm(cri)));
		model.addAttribute("listAdm", rService.listPagingAdm(cri));
	}
	
}
