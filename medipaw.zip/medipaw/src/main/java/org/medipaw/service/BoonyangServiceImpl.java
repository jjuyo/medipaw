package org.medipaw.service;

import java.util.List;

import org.medipaw.domain.BoonyangVO;
import org.medipaw.domain.Criteria;
import org.medipaw.mapper.BoonyangMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class BoonyangServiceImpl implements BoonyangService {
	@Setter(onMethod_ = @Autowired)
	private BoonyangMapper byMapper;


	@Override
	public List<BoonyangVO> pageList(Criteria cri) {
		log.info("pageList.....");
		return byMapper.selectAllPaging(cri);
	}
	
	@Override
	public List<BoonyangVO> myList(String id, Criteria cri) {
		// TODO Auto-generated method stub
		return byMapper.selectMyList(id, cri);
	}

	@Override
	public boolean register(BoonyangVO bvo) {
		log.info("register...." + bvo);
		return byMapper.insert(bvo) == 1;
	}

//	@Override
//	public String attachList(int Byno) {
////		log.info("attachList.....");
////		return byAttachMapper.select(Byno); //게시판 상세보기에서 첨부파일 리스트
//	}
	

	@Override
	public BoonyangVO view(int Byno) {
		log.info("view.....");
		return byMapper.select(Byno);
	}
	
	@Transactional
	@Override
	public boolean remove(int Byno) {
		log.info("remove..." + Byno);
		
		boolean result = byMapper.delete(Byno) == 1;
		
		return result;
	}

	@Override
	public boolean modify(BoonyangVO bvo) {
		log.info("modify..." + bvo);
		return byMapper.update(bvo)==1;
	}

	@Override
	public int totalCount(Criteria cri) {
		log.info("totalCnt.....");
		return byMapper.totalCount(cri);
	}

	@Override
	public String attachList(int byno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int mytotalCount(String id, Criteria cri) {
		log.info("mytotalCnt.....");
		return byMapper.mytotalCount(id, cri);
	}


}