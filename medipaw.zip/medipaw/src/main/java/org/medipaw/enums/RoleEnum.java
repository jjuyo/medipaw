package org.medipaw.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum RoleEnum {
	ROLE_ADMIN,
	ROLE_MEMBER,
	ROLE_STAFF;
}
