package org.medipaw.service;

import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.medipaw.domain.Criteria;
import org.medipaw.domain.SiljongVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class SiljongServiceTests {	// bean들이 잘 만들어지는지 확인
	@Setter(onMethod_ = @Autowired)
	private SiljongService sjService;
	
	
	public void testSearch() {			// 검색되는지 테스트
		log.info("testSearch...");
		Criteria cri = new Criteria();	// 기본 생성자로 1페이지 테스트
		cri.setType("TC");				// 제목 또는 내용에서 검색
		cri.setKeyword("new");			// new로 검색 시
		sjService.listPaging(cri);	// 목록 테스트
		sjService.totalCount(cri);	// 게시물 수 테스트
	}
	
	
	public void testListPaging() {			// 페이징되는지 테스트
		log.info("listTest...");
		Criteria cri = new Criteria();	// 매개변수 생성자로 2페이지 테스트
		sjService.listPaging(cri);
		sjService.totalCount(cri);		// 게시물 수 테스트
	}
	
	public void testModify() {
		SiljongVO bvo = sjService.view(11);	// new BoradVO() 해서 bvo.setBno해도 되고 하나만 view해서 
		if(bvo == null) {	// 게시물이 있는지 확인
			return;			// 있으면 업데이트 시작
		}
		
//		bvo.setTitle("update title");
//		bvo.setContent("update content");
//		bvo.setWriter("updater");
		sjService.modify(bvo);
		
		log.info("UPDATE RESULT : " + sjService.modify(bvo));	
		// UPDATE RESULT : true
	}
	
	public void testRemove() {
		log.info("DELETE RESULT : " + sjService.remove(9));
		// DELETE RESULT : true
	}
	
	@Test
	public void testListView() {			// select 되는지 테스트
		log.info("listTest...");
		sjService.view(25);
	}
	
	public void testRegister() {
		SiljongVO bvo = new SiljongVO();
//		bvo.setTitle("new title");
//		bvo.setContent("new content");
//		bvo.setWriter("newbie");
		sjService.register(bvo);
		
		// 생성된 게시물 번호 : 11
	}
	
}
