package org.medipaw.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.medipaw.domain.Criteria;
import org.medipaw.domain.TreatVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class TreatServiceTests {	// bean들이 잘 만들어지는지 확인
	@Setter(onMethod_ = @Autowired)
	private TreatService trService;
	
	
	public void testSearch() {			// 검색되는지 테스트
		log.info("testSearch...");
		Criteria cri = new Criteria();	// 기본 생성자로 1페이지 테스트
//		cri.setType("M");				// 제목 또는 내용에서 검색
//		cri.setKeyword("3");			// new로 검색 시
//		log.info(trService.listPagingUser("test3", cri));	// 목록 테스트
//		log.info(trService.totalCountUser("test3", cri));	// 게시물 수 테스트
//		log.info(trService.listPagingStaff(1, cri));	// 목록 테스트
//		log.info(trService.totalCountStaff(1, cri));	// 게시물 수 테스트
		log.info(trService.listPagingAdm(cri));	// 목록 테스트
		log.info(trService.totalCountAdm(cri));	// 게시물 수 테스트
	}
	
	
	public void testCnt() {
		trService.treatCnt(101);
	}
	
	
	public void testModify() {
		TreatVO tvo = trService.view(44);	// new BoradVO() 해서 bvo.setBno해도 되고 하나만 view해서 
		if(tvo == null) {	// 게시물이 있는지 확인
			return;			// 있으면 업데이트 시작
		}
		
		tvo.setTno(44);
		tvo.setTrDate("2023-10-19");
		tvo.setTrTime("17:00");
		tvo.setTrNote("초코 다 나음~");
		trService.modify(tvo);
		
		log.info("UPDATE RESULT : " + trService.modify(tvo));	
		// UPDATE RESULT : true
	}
	
	
	public void testRemove() {
		log.info("DELETE RESULT : " + trService.remove(42));
		// DELETE RESULT : true
	}
	
	
	public void testListView() {			// select 되는지 테스트
		log.info("listTest...");
//		TreatVO tvo = trService.view(44);
//		log.info(tvo);
//		log.info(tvo.getHvo());
		trService.view(44);
	}
	
	@Test
	public void testRegister() {
		TreatVO tvo = new TreatVO();
		tvo.setTrDate("2023-10-17");
		tvo.setTrTime("15:00");
		tvo.setTrNote("뽀삐뽀삐뽀삐뽀삐뽀삐뽀삐");
		tvo.setHno(3);
		tvo.setRvno(103);
		tvo.setId("test3");
		trService.register(tvo);
		
		log.info("REGISTER RESULT : " + trService.register(tvo));
		// 생성된 게시물 번호 : 11
	}
	
	
	public void testExist() {
		assertNotNull(trService);
		log.info(trService);
	}
}
