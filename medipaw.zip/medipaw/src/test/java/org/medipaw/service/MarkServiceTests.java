package org.medipaw.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.medipaw.domain.Criteria;
import org.medipaw.domain.MarkVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class MarkServiceTests {	// bean들이 잘 만들어지는지 확인
	@Setter(onMethod_ = @Autowired)
	private MarkService mService;
	
	@Test
	public void testList() {			// 검색되는지 테스트
		log.info("testList...");
		Criteria cri = new Criteria();	// 기본 생성자로 1페이지 테스트
		String id = "test";
		log.info(mService.listHos(id, cri));	// 병원 가나다순
		log.info(mService.listMno(id, cri));	// 등록 최신순
		log.info(mService.totalCount(id, cri));	// 게시물 수
	}
	
	
	public void testRemove() {
		log.info("DELETE RESULT : " + mService.remove(14));
		// DELETE RESULT : true
	}
	
	
	public void testRegister() {
		MarkVO mvo = new MarkVO();
		mvo.setHno(6);
		mvo.setId("test");
		mService.register(mvo);
		
		log.info("REGISTER RESULT : " + mService.register(mvo));
	}
	
}
