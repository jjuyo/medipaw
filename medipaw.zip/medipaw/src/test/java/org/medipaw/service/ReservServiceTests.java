package org.medipaw.service;

import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.medipaw.domain.Criteria;
import org.medipaw.domain.ReservVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReservServiceTests {	// bean들이 잘 만들어지는지 확인
	@Setter(onMethod_ = @Autowired)
	private ReservService rvService;
	
	@Test
	public void testSearch() {			// 검색되는지 테스트
		log.info("testSearch...");
		Criteria cri = new Criteria();	// 기본 생성자로 1페이지 테스트
//		cri.setType("M");				// 제목 또는 내용에서 검색
//		cri.setKeyword("2");			// new로 검색 시
		log.info(rvService.listPagingAdm(cri));	// 목록 테스트
		log.info(rvService.totalCountAdm(cri));	// 게시물 수 테스트
	}
	
	
	public void testModify() {
		ReservVO rvvo = rvService.view(10);	// new BoradVO() 해서 bvo.setBno해도 되고 하나만 view해서 
		if(rvvo == null) {	// 게시물이 있는지 확인
			return;			// 있으면 업데이트 시작
		}
		
		rvvo.setPetName("뽀삐");
		rvvo.setPetGender("암컷");
		rvvo.setPetSpecies("말티즈");
		rvvo.setPetNote("뽀삐 아픔");
		rvService.modify(rvvo);
		
		log.info("UPDATE RESULT : " + rvService.modify(rvvo));	
		// UPDATE RESULT : true
	}
	
	public void testRemove() {
		log.info("DELETE RESULT : " + rvService.remove(9));
		// DELETE RESULT : true
	}
	
	
	public void testListView() {			// select 되는지 테스트
		log.info("listTest...");
		rvService.view(20);
	}
	
	
	public void testRegister() {
		ReservVO rvvo = new ReservVO();
		//rvvo.setRvDate("2023-10-17");
		rvvo.setRvTime("15:00");
		rvvo.setPetName("뽀삐");
		rvvo.setPetSpecies("말티즈");
		rvvo.setPetGender("암컷");
		rvvo.setPetNote("뽀삐 아프다");
		rvvo.setHno(1);
		rvvo.setId("test2");
		rvService.register(rvvo);
		
		log.info("UPDATE RESULT : " + rvService.register(rvvo));
		// 생성된 게시물 번호 : 11
	}
	
	public void testExist() {
		assertNotNull(rvService);
		log.info(rvService);
	}
}
