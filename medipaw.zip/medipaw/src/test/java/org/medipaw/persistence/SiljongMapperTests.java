package org.medipaw.persistence;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.medipaw.domain.Criteria;
import org.medipaw.domain.SiljongVO;
import org.medipaw.mapper.SiljongMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class SiljongMapperTests {
	@Setter(onMethod_ = @Autowired)
	private  SiljongMapper sjMapper;
	
	
	public void testSelect() {					// select 되는지 테스트
		Criteria cri = new Criteria(10, 1);
		String id = "test";
		sjMapper.selectMine(id, cri);
		sjMapper.totalCountMine(id, cri);
	}
	
	
	public void testInsert() {					// insert 되는지 테스트
		SiljongVO sjvo = new SiljongVO();
		sjvo.setSjTitle("뽀삐 실종 사건");
		sjvo.setSjContent("실종됐다 비상비상");
		sjvo.setId("test3");
		sjMapper.insert(sjvo);
		
		log.info(sjvo);
	}
	
	
	public void testDelete() {					// delete 되는지 테스트
		sjMapper.delete(33);
	}
	
	
	public void testUpdate() {					// update 되는지 테스트
		SiljongVO sjvo = new SiljongVO();
		sjvo.setSjno(38);
		sjvo.setSjTitle("뽀삐 찾았다잉");
		sjvo.setSjContent("찾았다 이눔~");
		sjvo.setSjState("구조");
		
		log.info("UPDATE COUNT : " + sjMapper.update(sjvo));
	}
	
	@Test
	public void testSearch() {
		Criteria cri = new Criteria();
		cri.setType("T");						// 작성자에서 검색
		cri.setKeyword("22");
		String id = "test";
		sjMapper.selectMine(id, cri);
		sjMapper.totalCountMine(id, cri);
	}
	
}
