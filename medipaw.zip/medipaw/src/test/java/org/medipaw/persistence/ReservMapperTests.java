package org.medipaw.persistence;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.medipaw.domain.Criteria;
import org.medipaw.domain.PageDTO;
import org.medipaw.domain.ReservVO;
import org.medipaw.mapper.ReservMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReservMapperTests {
	@Setter(onMethod_ = @Autowired)
	private  ReservMapper boardMapper;
	
	@Test
	public void testSelect() {					// select 되는지 테스트
		Criteria cri = new Criteria(10, 1);
		String id = "test2";
		String sid = "woori123";
		boardMapper.selectAllPagingStaff(sid, cri);
		boardMapper.totalCountStaff(sid, cri);
//		boardMapper.selectAllPagingUser(id, cri);
//		boardMapper.totalCountUser(id, cri);
	}
	
	
	public void testInsert() {					// insert 되는지 테스트
		ReservVO rvvo = new ReservVO();
		
		//rvvo.setRvDate("2023-10-16");
		rvvo.setRvTime("15:00");
		rvvo.setPetName("뽀삐");
		rvvo.setPetSpecies("말티즈");
		rvvo.setPetGender("암컷");
		rvvo.setPetNote("뽀삐 아프다");
		rvvo.setHno(1);
		rvvo.setId("test2");
		boardMapper.insert(rvvo);
		
		log.info(rvvo);
	}
	
	
	public void testDelete() {					// delete 되는지 테스트
		boardMapper.delete(23);
	}
	
	
	public void testUpdate() {					// update 되는지 테스트
		ReservVO rvvo = new ReservVO();
		rvvo.setRvno(26);
		rvvo.setPetName("뽀삐");
		rvvo.setPetGender("암컷");
		rvvo.setPetSpecies("말티즈");
		rvvo.setPetNote("뽀삐 아픔");
		
		log.info("UPDATE COUNT : " + boardMapper.update(rvvo));
	}
	
	public void testSearch() {
		Criteria cri = new Criteria();
		cri.setType("M");						// 작성자에서 검색
		cri.setKeyword("3");
		log.info("writer...." + boardMapper.selectAllPagingAdm(cri));
		log.info("totalcount : " + boardMapper.totalCountAdm(cri));
	}
	
}
