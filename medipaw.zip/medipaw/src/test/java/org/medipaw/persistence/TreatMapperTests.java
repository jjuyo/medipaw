package org.medipaw.persistence;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.medipaw.domain.Criteria;
import org.medipaw.domain.PageDTO;
import org.medipaw.domain.ReservVO;
import org.medipaw.domain.TreatVO;
import org.medipaw.mapper.TreatMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class TreatMapperTests {
	@Setter(onMethod_ = @Autowired)
	private  TreatMapper boardMapper;
	
	@Test
	public void testSelect() {					// select 되는지 테스트
		Criteria cri = new Criteria(10, 1);
		String id = "test3";
		String sid = "woori123";
		boardMapper.selectAllPagingStaff(sid, cri);
		boardMapper.totalCountStaff(sid, cri);
//		boardMapper.selectAllPagingUser(id, cri);
//		boardMapper.totalCountUser(id, cri);
	}
	
	
	public void testInsert() {					// insert 되는지 테스트
		TreatVO tvo = new TreatVO();
		tvo.setTrNote("뽀삐 완치~");
		tvo.setRvno(47);
		boardMapper.insert(tvo);
		
		log.info(tvo);
	}
	
	
	public void testDelete() {					// delete 되는지 테스트
		boardMapper.delete(33);
	}
	
	
	public void testUpdate() {					// update 되는지 테스트
		TreatVO rvvo = new TreatVO();
		rvvo.setTno(38);
		rvvo.setTrDate("2023-10-19");
		rvvo.setTrTime("14:00");
		rvvo.setTrNote("뽀삐 다 나았다!");
		
		log.info("UPDATE COUNT : " + boardMapper.update(rvvo));
	}
	
	
	public void testSearch() {
		Criteria cri = new Criteria();
		cri.setType("M");						// 작성자에서 검색
		cri.setKeyword("3");
		log.info("writer...." + boardMapper.selectAllPagingAdm(cri));
		log.info("totalcount : " + boardMapper.totalCountAdm(cri));
	}
	
}
