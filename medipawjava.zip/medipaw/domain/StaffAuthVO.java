package org.medipaw.domain;

import lombok.Data;

@Data
public class StaffAuthVO {
		private String sid, auth;
}
