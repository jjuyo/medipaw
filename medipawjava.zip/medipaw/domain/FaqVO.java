package org.medipaw.domain;

import lombok.Data;

@Data
public class FaqVO {
	private int faqNo;
	private String faqQ;
	private String faqA;

}
